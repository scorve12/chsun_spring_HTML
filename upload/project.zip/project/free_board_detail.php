<?php
	include $_SERVER['DOCUMENT_ROOT']."/db_con.php"; 
	include 'config.php';
?>
<!doctype html>
<head>
<meta charset="UTF-8">
<title>자유게시판</title>
</head>
<body>
	
	<?php
		function is_user_logged_in() {
			// 로그인 상태를 체크
			return isset($_SESSION['userid']);
		}

		function is_user_admin() {
			return ($_SESSION['role'] == 'ADMIN');
		}
		
		// 로그인이 안 되어 있으면 경고창
		if (!is_user_logged_in()) { ?>
			<script>
            	alert("로그인이 필요한 페이지입니다.");
            	history.back(); 
        	</script>
		<?php
		}
		// 로그인한 경우 데이터 불러옴.
		$bno = $_GET['idx']; /* bno함수에 idx값을 받아와 넣음*/
		$hit = mysqli_fetch_array(mc("SELECT * from free_board_table where idx ='".$bno."'"));
		$hit = $hit['view'] + 1;
		$fet = mc("UPDATE free_board_table set view = '".$hit."' where idx = '".$bno."'");
		$sql = mc("SELECT * from free_board_table where idx='".$bno."'"); /* 받아온 idx값을 선택 */
		$board = $sql->fetch_array();

		if (isset($_POST['recommend'])) {
			$user_id = $_SESSION['idx'];
		
			try {
				// 이미 해당 게시물을 추천했는지 확인
				$result = mc("SELECT * FROM liked_table WHERE user_id = '$user_id' AND post_id = '$bno'");
		
				if ($result->num_rows === 0) {
					// 해당 게시물에 추천 정보 추가
					mc("INSERT INTO liked_table (user_id, post_id) VALUES ('$user_id', '$bno')");
		
					// 추천 수 증가
					$like = $board['like_count'] + 1;
					mc("UPDATE free_board_table SET like_count = '$like' WHERE idx = '$bno'");
		
					// 메시지 출력 등 원하는 작업 수행
					?>
					<script>
						alert("게시물을 추천했습니다!"); 
						history.back();
					</script> <?php
				} else { ?>
				<script>
					alert("이미 게시물을 추천했습니다!"); 
					history.back();
				</script>
				<?php
				}
			} catch (Exception $e) {
				// 예외 처리 블록: 오류 발생 시 실행되는 코드
				echo "오류가 발생했습니다: " . $e->getMessage();
				// 또는 오류를 로그 파일에 기록하는 등 다른 처리를 수행할 수 있습니다.
			}
		}
	?>
<!-- 글 불러오기 -->
<div id="board_read">
	<h2><?php echo $board['title']; ?></h2>
		<div id="user_info">
			<?php echo $board['title']; ?>
				<div id="bo_line"></div>
			</div>
			<div id="bo_content">
				<?php echo nl2br("$board[content]"); ?>
			</div>
			<div class=middle>
			<?php if (!empty($board['file'])): ?>
				<p class="file"><a href="file/upload/<?=$board['file'];?>" download>다운로드<?=$board['file'];?></a></p>
			<?php endif; ?>
			</div>
			<form method="post">
                <input type="submit" name="recommend" value="추천">
            </form>
	<!-- 수정, 삭제 -->
	<div id="bo_ser">
		<ul>
			<li><a href="/">메인화면</a></li>
			<?php
				// 로그인한 사용자만 게시물을 읽을 수 있도록 체크
				if (is_user_logged_in()) {
					// 일반 사용자인 경우
					if ($_SESSION['userid'] == $board['name']) { ?>
						<!-- 일반유저인 경우 자신글에 대한 수정, 삭제 가능 -->
						<li><a href="modify.php?idx=<?php echo $board['idx']; ?>">수정</a></li>
						<li><a href="delete.php?idx=<?php echo $board['idx']; ?>">삭제</a></li>
					</ul><?php
					} elseif (is_user_admin()) { ?>
						<!-- 관리자인 경우 모든 유저 삭제 가능 -->
						<li><a href="delete.php?idx=<?php echo $board['idx']; ?>">삭제</a></li>
						<?php
					}
				}
			?>
	</div>
</div>
</body>
</html>
