<?php
	include 'config.php';
	$db_host = "localhost:3306";
	$db_id = "padmin";
	$db_pw = "duswnsKKhc117!";
	$db_name = "hacker_test";
	$connect= mysqli_connect($db_host, $db_id, $db_pw, $db_name);

	// $query = "SELECT * from member_table ORDER BY NUMBER DESC";
    // $result = mysqli_query($connect, $query);

    // $total = mysqli_num_rows($result);  //result set의 총 레코드(행) 수 반환

    if (isset($_SESSION['userid'])) {
    ?><b><?php echo $_SESSION['userid']; echo $role; ?></b>님 반갑습니다.
        <button onclick="location.href='./logout_action.php'" style="float:right; font-size:15.5px;">로그아웃</button>
        <br />
    <?php
    } else {
    ?>
        <button onclick="location.href='./login.php'" style="float:right; font-size:15.5px;">로그인</button>
        <br />
    <?php
    }
    ?>

	<!DOCTYPE html>
	<html lang="ko">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Document</title>
	</head>
	<body>
		<div>
		<table class="list-table">
      <thead>
          <tr>
              <th width="100"><button onclick="location.href='./inform_board.php'">공지사항</button></th>
			  <th width="100"><button onclick="location.href='./free_board.php'">자유게시판</button></th>
			  <th width="100"><button onclick="location.href='./qna_board.php'">질문게시판</button></th>
            </tr>
        </thead>
		</table>
		</div>
	</body>
	</html>